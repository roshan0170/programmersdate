# beginner-html-site
A simple one page website created to help complete beginners learn HTML basics. This example is built up over the course of [https://developer.mozilla.org/en-US/Learn/Getting_started_with_the_web/HTML_basics](https://developer.mozilla.org/en-US/Learn/Getting_started_with_the_web/HTML_basics).
