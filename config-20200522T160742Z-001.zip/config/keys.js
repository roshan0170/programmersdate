const keys = {
  apikey:"hxn--kO6wgj7SzDxrn1_85oYQM3-1o2BH8Ubr9JLs2pC"
}

module.exports = keys;